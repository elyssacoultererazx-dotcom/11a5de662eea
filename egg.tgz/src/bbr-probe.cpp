// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Probe bottleneck bandwidth"); }
int main(){
  announce();
  return lionss_run_workload("bbr-probe");
}
