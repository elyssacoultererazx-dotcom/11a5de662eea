// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Detect nightjar calls"); }
int main(){
  announce();
  return lionss_run_workload("nightjar");
}
