// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Process RTCP feedback\n", stdout);
  return lionss_run_workload("rtcpFeedback");
}
