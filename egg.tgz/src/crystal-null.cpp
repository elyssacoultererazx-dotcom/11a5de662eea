// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Check nil safety"); }
int main(){
  announce();
  return lionss_run_workload("crystal-null");
}
