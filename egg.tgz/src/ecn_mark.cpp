// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Mark ECN on congestion\n", stdout);
  return lionss_run_workload("ecn_mark");
}
