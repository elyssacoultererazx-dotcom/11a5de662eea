// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Encode 48k stream");
  std::fflush(stdout);
  return lionss_run_workload("opus_encode48k");
}
