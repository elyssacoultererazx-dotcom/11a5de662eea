// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Simulate brightwater flow"); }
int main(){
  announce();
  return lionss_run_workload("brightwater-7");
}
