// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Grow cedar grove\n", stdout);
  return lionss_run_workload("cedar_grove");
}
